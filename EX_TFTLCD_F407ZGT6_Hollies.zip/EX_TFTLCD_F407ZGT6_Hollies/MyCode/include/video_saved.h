#ifndef __VIDEO_SAVED_
#define __VIDEO_SAVED_

typedef struct
{
    const unsigned char (*TDArray);
}Animation_Array;

extern const unsigned char bmp[][1024];
// extern const unsigned char bmp1[115200];
// extern Animation_Array a[];
#endif
